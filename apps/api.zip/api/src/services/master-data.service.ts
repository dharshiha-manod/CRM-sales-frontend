import { AppError } from '../errors/app-error.js';
import { assertRecordInScope, isGlobalRole, resolveIndustryTypeId, type IndustryScope } from '../lib/industry-scope.js';
import { validateIndustryDetails } from '../lib/industry-profile.js';
import { getIndustryType } from '../repositories/industry-types.repository.js';
import * as repo from '../repositories/master-data.repository.js';
import { listRequirements } from '../repositories/requirements.repository.js';
import { listQuotations } from '../repositories/quotations.repository.js';

const clientNotFound = () => new AppError(404, 'CLIENT_NOT_FOUND', 'Client was not found');

async function resolveIndustryCode(org: string, industryTypeId?: string | null): Promise<string | null> {
  if (!industryTypeId) return null;
  const type = await getIndustryType(org, industryTypeId);
  return (type as { code: string }).code;
}

function cleanIndustryDetails(code: string | null, details: unknown) {
  try {
    return validateIndustryDetails(code, details as Record<string, unknown> | undefined);
  } catch (error) {
    throw new AppError(422, 'INVALID_INDUSTRY_DETAILS', (error as Error).message);
  }
}

export const representativeService = { list(org: string, search: string | undefined, status: string | undefined, industryTypeId: string | undefined, scope: IndustryScope) { return repo.listRepresentatives(org, search, status, resolveIndustryTypeId(scope, industryTypeId) ?? undefined); }, get: repo.getRepresentative, async create(org: string, input: Record<string, unknown>) { await repo.assertRepresentativeUserMembership(org, input.userId as string); return repo.createRepresentative(org, input); }, update: repo.updateRepresentative };

/** Multi-country fields (countryCode / currencyCode) are an FMCG + Trading feature.
 *  For every other industry they are dropped server-side, so those industries behave exactly as before. */
function applyMultiCountryRule(code: string | null, input: Record<string, unknown>): Record<string, unknown> {
  const next = { ...input };
  if (!['fmcg', 'trading'].includes((code ?? '').toLowerCase())) {
    delete next.countryCode;
    delete next.currencyCode;
    return next;
  }
  if (typeof next.countryCode === 'string') next.countryCode = next.countryCode.toUpperCase();
  if (typeof next.currencyCode === 'string') next.currencyCode = next.currencyCode.toUpperCase();
  return next;
}

export const clientService = {
  list(org: string, search: string | undefined, type: string | undefined, status: string | undefined, industryTypeId: string | undefined, scope: IndustryScope) {
    const effective = resolveIndustryTypeId(scope, industryTypeId);
    return repo.listClients(org, search, type, status, effective ?? undefined);
  },
  async get(org: string, id: string, scope: IndustryScope) {
    const client = await repo.getClient(org, id);
    assertRecordInScope(scope, (client as { industry_type_id?: string | null }).industry_type_id, clientNotFound());
    return client;
  },
  async create(org: string, input: Record<string, unknown>, scope: IndustryScope) {
    const industryTypeId = resolveIndustryTypeId(scope, input.industryTypeId as string | null | undefined);
    const code = await resolveIndustryCode(org, industryTypeId);
    const base = applyMultiCountryRule(code, input);
    return repo.createClient(org, { ...base, industryTypeId, industryDetails: cleanIndustryDetails(code, input.industryDetails) });
  },
  async update(org: string, id: string, input: Record<string, unknown>, scope: IndustryScope) {
    const existing = await repo.getClient(org, id);
    assertRecordInScope(scope, (existing as { industry_type_id?: string | null }).industry_type_id, clientNotFound());
    if ('industryTypeId' in input && !isGlobalRole(scope.role)) {
      throw new AppError(403, 'INDUSTRY_NOT_ASSIGNED', 'You are not assigned to this industry.');
    }
    const touchesIndustry = 'industryTypeId' in input || 'industryDetails' in input;
    const touchesCountry = 'countryCode' in input || 'currencyCode' in input;
    // Requests that touch neither keep the exact original path (no extra lookups for any industry).
    if (!touchesIndustry && !touchesCountry) return repo.updateClient(org, id, input);
    const industryTypeId = ('industryTypeId' in input ? input.industryTypeId : (existing as { industry_type_id?: string | null }).industry_type_id) as string | null | undefined;
    const code = await resolveIndustryCode(org, industryTypeId);
    const base = applyMultiCountryRule(code, input);
    if (Object.keys(base).length === 0) return existing; // non-FMCG client sent only country fields: nothing to save
    if (!touchesIndustry) return repo.updateClient(org, id, base);
    return repo.updateClient(org, id, { ...base, industryDetails: cleanIndustryDetails(code, input.industryDetails) });
  },
  async syncAddressFromLead(org: string, id: string, scope: IndustryScope) {
    const client = await repo.getClient(org, id);
    assertRecordInScope(scope, (client as { industry_type_id?: string | null }).industry_type_id, clientNotFound());
    return repo.syncClientAddressFromLead(org, id);
  },
  async addressSyncStatus(org: string, id: string, scope: IndustryScope) {
    const client = await repo.getClient(org, id);
    assertRecordInScope(scope, (client as { industry_type_id?: string | null }).industry_type_id, clientNotFound());
    return repo.clientAddressSyncStatus(org, id, client);
  },
  contacts: { list: repo.listContacts, create: repo.createContact, update: repo.updateContact, remove: repo.deleteContact },
  assignments: { list: repo.listAssignedClients, assign: repo.assignClient, remove: repo.unassignClient },
/**
 * NEW — powers Trading > Deal Management's "select a customer, auto-fill
 * the rest" flow. Reuses the existing requirements/quotations repository
 * functions as-is (no new tables, no new duplicate logic) and just shapes
 * their output for the Deal form. Priority, per the Deal auto-fill spec:
 * an accepted quotation first, then the customer's latest open
 * requirement, so the frontend can auto-select when there's exactly one
 * candidate and otherwise offer a picker.
 *
 * quotationStatuses defaults to just ['accepted'] so Deal Management's
 * existing "auto-select when there's exactly one candidate" behavior is
 * completely unchanged. Purchase Enquiry's customer-quantity auto-fill
 * (a read-only lookup, not a candidate picker) passes a wider set —
 * ['accepted', 'converted'] — because a quotation the customer already
 * converted to an order is at least as confirmed as an "accepted" one,
 * and excluding it was why that auto-fill was coming up blank.
 */
async tradingSnapshot(org: string, id: string, scope: IndustryScope, quotationStatuses: string[] = ['accepted']) {
  const client = await clientService.get(org, id, scope); // also enforces industry scope / 404
  const [requirements, quotations] = await Promise.all([
    listRequirements(org, { clientId: id }),
    listQuotations(org, { clientId: id }),
  ]);
  const openRequirements = (requirements ?? []).filter((r: any) => r.status === 'open' || r.status === 'quoted');
  const matchingQuotations = (quotations ?? []).filter((q: any) => quotationStatuses.includes(q.status));
  return { client, requirements: openRequirements, quotations: matchingQuotations };
  },
};
import { useEffect, useMemo, useState } from 'react';
import { api } from '../lib/api';
import { collectionsInInr, ordersInInr } from '../lib/inr';
import { kpiClick } from '../lib/kpiClick';
import { KpiDetailModal } from './KpiDetailModal';
import { useIndustryScope } from '../industry/useIndustryScope';
import './MasterDataPages.css';

type Assignment = { id: string; status: string; sales_representatives?: { employee_code: string; user_profiles?: { display_name?: string | null } | null } | null };
type Client = {
  id: string;
  client_code: string;
  client_name: string;
  client_type: string;
  outlet_type?: string | null;
  industry_type_id?: string | null;
  status: 'active' | 'inactive';
  priority: 'low' | 'normal' | 'high' | 'critical';
  city?: string | null;
  gstin?: string | null;
  credit_limit?: number | null;
  credit_days?: number | null;
  sales_representative_client_assignments?: Assignment[];
};
type Order = { id: string; order_number: string; status: string; total_amount: number; created_at: string; client_id?: string; distributor_id?: string | null; clients?: { client_name?: string } | null; sale_order_items?: { quantity: number; products?: { unit?: string | null } | null }[] };
type Roll = { order_id?: string | null; length_meters?: number | null };
const isMetre = (unit?: string | null) => !unit || /^(m|mtr|mtrs|meter|meters|metre|metres)$/i.test(unit.trim());
type Collection = { id: string; amount: number; mode: string; collected_at: string; client_id?: string };

const money = (value: number) => new Intl.NumberFormat('en-IN', { style: 'currency', currency: 'INR', maximumFractionDigits: 0 }).format(value);

function activeRep(client: Client): string {
  const assignment = client.sales_representative_client_assignments?.find((a) => a.status === 'active') ?? client.sales_representative_client_assignments?.[0];
  return assignment?.sales_representatives?.user_profiles?.display_name ?? assignment?.sales_representatives?.employee_code ?? '';
}

const AVATAR_PALETTE = ['#c6791f', '#3d5a80', '#8b5a83', '#2e7d6b', '#3f6b4a', '#a6402b'];
function avatarColor(seed: string): string {
  let hash = 0;
  for (let i = 0; i < seed.length; i += 1) hash = (hash * 31 + seed.charCodeAt(i)) >>> 0;
  return AVATAR_PALETTE[hash % AVATAR_PALETTE.length];
}
function initials(name: string): string {
  const parts = name.trim().split(/\s+/).filter(Boolean);
  if (!parts.length) return '—';
  return (parts[0][0] + (parts[1]?.[0] ?? '')).toUpperCase();
}

export function DistributorPage({ industryLabel = 'FMCG' }: { industryLabel?: string } = {}) {
  const { activeIndustryTypeId } = useIndustryScope();
  const [clients, setClients] = useState<Client[]>([]);
  const [orders, setOrders] = useState<Order[]>([]);
  const [collections, setCollections] = useState<Collection[]>([]);
  const [rolls, setRolls] = useState<Roll[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [message, setMessage] = useState('');

  const [search, setSearch] = useState('');
  const [statusFilter, setStatusFilter] = useState<'all' | Client['status']>('all');
  const [creditFilter, setCreditFilter] = useState<'all' | 'healthy' | 'watch' | 'over'>('all');

  const [viewing, setViewing] = useState<Client | null>(null);
  const [kpiView, setKpiView] = useState<null | 'credit' | 'outstanding'>(null);

  async function load() {
    setLoading(true);
    setError(null);
    try {
      const [clientsRes, ordersRes, collectionsRes] = await Promise.all([
        api<{ data: Client[] }>('/clients'),
        api<{ data: Order[] }>('/orders').catch(() => ({ data: [] })),
        api<{ data: Collection[] }>('/collections').catch(() => ({ data: [] })),
      ]);
      // Only distributors that belong to the active industry (Textile) — never other industries' distributors.
      const scoped = (clientsRes.data ?? []).filter((c) => (c.outlet_type ?? '').toLowerCase() === 'distributor' && c.industry_type_id === activeIndustryTypeId);
      setClients(scoped);
     setOrders(ordersInInr(ordersRes).data ?? []);
setCollections(collectionsInInr(collectionsRes).data ?? []);
      if (industryLabel.toLowerCase() === 'textile') {
        const rollsRes = await api<{ data: Roll[] }>(`/textile/fabric-rolls?industryTypeId=${activeIndustryTypeId}`).catch(() => ({ data: [] as Roll[] }));
        setRolls(rollsRes.data ?? []);
      }
    } catch (caught) {
      setError(caught instanceof Error ? caught.message : 'Unable to load distributor data.');
    } finally {
      setLoading(false);
    }
  }
  useEffect(() => {
    if (!activeIndustryTypeId) return;
    void load();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [activeIndustryTypeId]);

  function ledger(clientId: string) {
    const clientOrders = orders.filter((o) => o.client_id === clientId && o.status !== 'cancelled');
    const clientCollections = collections.filter((c) => c.client_id === clientId);
    const totalSales = clientOrders.reduce((sum, o) => sum + (o.total_amount ?? 0), 0);
    const totalCollected = clientCollections.reduce((sum, c) => sum + (c.amount ?? 0), 0);
    const outstanding = Math.max(0, totalSales - totalCollected);
    const lastOrder = clientOrders.slice().sort((a, b) => new Date(b.created_at).getTime() - new Date(a.created_at).getTime())[0];
    return { orderCount: clientOrders.length, totalSales, totalCollected, outstanding, lastOrderDate: lastOrder?.created_at ?? null };
  }

  /** Orders this distributor delivers to the end clients (Model B): count, ordered metres and metres of rolls issued against them. */
  function handled(distributorId: string) {
    const list = orders.filter((o) => o.distributor_id === distributorId && o.status !== 'cancelled');
    const ids = new Set(list.map((o) => o.id));
    const metres = list.reduce((sum, o) => sum + (o.sale_order_items ?? []).filter((i) => isMetre(i.products?.unit)).reduce((s, i) => s + Number(i.quantity || 0), 0), 0);
    const rollRows = rolls.filter((r) => r.order_id && ids.has(r.order_id));
    const rollMetres = rollRows.reduce((sum, r) => sum + Number(r.length_meters ?? 0), 0);
    return { list, count: list.length, metres, rollCount: rollRows.length, rollMetres };
  }

  function creditTone(client: Client, outstanding: number): 'healthy' | 'watch' | 'over' {
    if (!client.credit_limit) return 'healthy';
    const pct = outstanding / client.credit_limit;
    if (pct >= 1) return 'over';
    if (pct >= 0.75) return 'watch';
    return 'healthy';
  }

  const rows = useMemo(() => {
    return clients.map((c) => ({ client: c, ...ledger(c.id), rep: activeRep(c), handled: handled(c.id) }));
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [clients, orders, collections, rolls]);

  const filteredRows = useMemo(() => {
    const q = search.trim().toLowerCase();
    return rows.filter((r) => {
      if (statusFilter !== 'all' && r.client.status !== statusFilter) return false;
      const tone = creditTone(r.client, r.outstanding);
      if (creditFilter !== 'all' && tone !== creditFilter) return false;
      if (!q) return true;
      return (
        r.client.client_name.toLowerCase().includes(q) ||
        r.client.client_code.toLowerCase().includes(q) ||
        (r.client.city ?? '').toLowerCase().includes(q) ||
        r.rep.toLowerCase().includes(q)
      );
    });
  }, [rows, search, statusFilter, creditFilter]);

  async function toggleStatus(client: Client) {
    try {
      await api(`/clients/${client.id}/status`, { method: 'PATCH', body: JSON.stringify({ status: client.status === 'active' ? 'inactive' : 'active' }) });
      setMessage('Distributor status updated successfully.');
      await load();
    } catch (caught) {
      setMessage(caught instanceof Error ? caught.message : 'Unable to update status.');
    }
  }

  function openView(client: Client) {
    setViewing(client);
  }

  const totalDistributors = clients.length;
  const activeDistributors = clients.filter((c) => c.status === 'active').length;
  const totalCreditExtended = clients.reduce((sum, c) => sum + (c.credit_limit ?? 0), 0);
  const totalOutstanding = rows.reduce((sum, r) => sum + r.outstanding, 0);
  const overLimitCount = rows.filter((r) => creditTone(r.client, r.outstanding) === 'over').length;
  const creditRows = rows.filter((r) => (r.client.credit_limit ?? 0) > 0).sort((a, b) => (b.client.credit_limit ?? 0) - (a.client.credit_limit ?? 0));
  const outstandingRows = rows.filter((r) => r.outstanding > 0).sort((a, b) => b.outstanding - a.outstanding);

  const viewingLedger = viewing ? ledger(viewing.id) : null;
  const viewingHandled = viewing ? handled(viewing.id) : null;
  const viewingOrders = viewing ? orders.filter((o) => o.client_id === viewing.id).slice().sort((a, b) => new Date(b.created_at).getTime() - new Date(a.created_at).getTime()) : [];
  const viewingCollections = viewing ? collections.filter((c) => c.client_id === viewing.id).slice().sort((a, b) => new Date(b.collected_at).getTime() - new Date(a.collected_at).getTime()) : [];

  return (
    <section className="page-panel master-page">
      <div className="page-panel-heading">
        <div>
          <p className="eyebrow">{industryLabel.toUpperCase()} · DISTRIBUTOR MANAGEMENT</p>
          <h2>Distributor management</h2>
          <p>Track distributor credit health, order volume and collections. Distributors are clients tagged with outlet type "Distributor" — add or edit one from the Clients directory.</p>
        </div>
      </div>

         <div className="kpi-grid">
       <div className="kpi-card" data-tone="ink" {...kpiClick(statusFilter === 'all' && creditFilter === 'all' && !search.trim(), () => { setStatusFilter('all'); setCreditFilter('all'); setSearch(''); })}>
          <div className="kpi-icon">▤</div>
          <div>
            <span>Distributors</span>
            <strong>{totalDistributors}</strong>
            <small>{activeDistributors} active</small>
          </div>
        </div>
<div className="kpi-card" data-tone="blue" {...kpiClick(kpiView === 'credit', () => setKpiView('credit'))}>
          <div className="kpi-icon">₹</div>
          <div>
            <span>Credit extended</span>
            <strong>{money(totalCreditExtended)}</strong>
            <small>combined credit limit</small>
          </div>
        </div>
  <div className="kpi-card" data-tone="amber" {...kpiClick(kpiView === 'outstanding', () => setKpiView('outstanding'))}>
          <div className="kpi-icon">◒</div>
          <div>
            <span>Outstanding</span>
            <strong>{money(totalOutstanding)}</strong>
            <small>across all distributors</small>
          </div>
        </div>
     <div className="kpi-card" data-tone={overLimitCount > 0 ? 'red' : 'green'} {...kpiClick(creditFilter === 'over', () => { setCreditFilter('over'); setStatusFilter('all'); setSearch(''); })}>
          <div className="kpi-icon">⚠</div>
          <div>
            <span>Over credit limit</span>
            <strong>{overLimitCount}</strong>
            <small>need collection follow-up</small>
          </div>
        </div>
      </div>

      <div className="master-toolbar">
        <div className="master-search">
          <input
            type="search"
            placeholder="Search distributor, city or representative…"
            value={search}
            onChange={(e) => setSearch(e.target.value)}
          />
          <select value={statusFilter} onChange={(e) => setStatusFilter(e.target.value as 'all' | Client['status'])}>
            <option value="all">All statuses</option>
            <option value="active">Active</option>
            <option value="inactive">Inactive</option>
          </select>
          <select value={creditFilter} onChange={(e) => setCreditFilter(e.target.value as typeof creditFilter)}>
            <option value="all">All credit health</option>
            <option value="healthy">Healthy</option>
            <option value="watch">Near limit</option>
            <option value="over">Over limit</option>
          </select>
        </div>
      </div>

      {error && <p className="error-message">{error}</p>}
      {message && <p className={message.includes('successfully') ? 'success-message' : 'error-message'}>{message}</p>}

      {loading ? (
        <div className="data-table-wrap">
          <table>
            <thead>
              <tr>
                <th>Distributor</th>
                <th>City</th>
                <th>Representative</th>
                <th>Credit terms</th>
                <th>Orders</th>
                <th>Handled for clients</th>
                <th>Outstanding</th>
                <th>Status</th>
                <th>Actions</th>
              </tr>
            </thead>
            <tbody>
              {[0, 1, 2, 3].map((i) => (
                <tr key={i} className="skeleton-row">
                  <td><span className="skeleton-block" style={{ width: '75%' }} /></td>
                  <td><span className="skeleton-block" style={{ width: '55%' }} /></td>
                  <td><span className="skeleton-block" style={{ width: '60%' }} /></td>
                  <td><span className="skeleton-block" style={{ width: '65%' }} /></td>
                  <td><span className="skeleton-block" style={{ width: '30%' }} /></td>
                  <td><span className="skeleton-block" style={{ width: '40%' }} /></td>
                  <td><span className="skeleton-block" style={{ width: '55%' }} /></td>
                  <td><span className="skeleton-block" style={{ width: '50%' }} /></td>
                  <td><span className="skeleton-block" style={{ width: '70%' }} /></td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      ) : (
        <div className="data-table-wrap">
          <table>
            <thead>
              <tr>
                <th>Distributor</th>
                <th>City</th>
                <th>Representative</th>
                <th>Credit terms</th>
                <th>Orders</th>
                <th>Handled for clients</th>
                <th>Outstanding</th>
                <th>Status</th>
                <th>Actions</th>
              </tr>
            </thead>
            <tbody>
              {filteredRows.map(({ client, orderCount, totalSales, outstanding, rep, handled: h }) => {
                const tone = creditTone(client, outstanding);
                const pct = client.credit_limit ? Math.min(100, Math.round((outstanding / client.credit_limit) * 100)) : 0;
                return (
                  <tr key={client.id}>
                    <td>
                      <strong>{client.client_name}</strong>
                      <small>{client.client_code}</small>
                    </td>
                    <td>{client.city || '—'}</td>
                    <td>
                      {rep ? (
                        <div className="rep-cell">
                          <span className="rep-avatar" style={{ background: avatarColor(rep) }}>{initials(rep)}</span>
                          <span>{rep}</span>
                        </div>
                      ) : (
                        <span className="text-faint-inline">Unassigned</span>
                      )}
                    </td>
                    <td>{client.credit_limit != null ? `${money(client.credit_limit)} · ${client.credit_days ?? 0}d` : '—'}</td>
                    <td>
                      {orderCount}
                      <small style={{ display: 'block', color: 'var(--text-faint)' }}>{money(totalSales)}</small>
                    </td>
                    <td>
                      {h.count}
                      <small style={{ display: 'block', color: 'var(--text-faint)' }}>{h.metres.toLocaleString('en-IN', { maximumFractionDigits: 2 })} m</small>
                    </td>
                    <td>
                      <div className="coverage-cell">
                        {client.credit_limit ? (
                          <div className="coverage-bar"><div className={`coverage-bar-fill ${tone === 'over' ? 'tone-over' : tone === 'watch' ? 'tone-watch' : ''}`} style={{ width: `${pct}%` }} /></div>
                        ) : null}
                        <span className={outstanding > 0 ? 'text-warn' : ''}>{money(outstanding)}</span>
                      </div>
                    </td>
                    <td>
                      <span className={`status-badge ${client.status}`}>{client.status}</span>
                    </td>
                    <td className="master-actions">
                      <button type="button" className="icon-action" title="View distributor" aria-label={`View ${client.client_name}`} onClick={() => openView(client)}>
                        ◉
                      </button>
                      <button
                        type="button"
                        className="icon-action"
                        title={client.status === 'active' ? 'Deactivate' : 'Activate'}
                        aria-label={`Change status of ${client.client_name}`}
                        onClick={() => void toggleStatus(client)}
                      >
                        {client.status === 'active' ? '⊘' : '✓'}
                      </button>
                    </td>
                  </tr>
                );
              })}
              {filteredRows.length === 0 && (
                <tr>
                  <td colSpan={9} className="empty-row">
                    <div className="empty-state">
                      <span className="empty-state-icon">▤</span>
                      <p>
                        {clients.length === 0
                          ? 'No distributors yet. Tag a client with outlet type "Distributor" in the Clients directory.'
                          : 'No distributors match your search or filters.'}
                      </p>
                    </div>
                  </td>
                </tr>
              )}
            </tbody>
          </table>
        </div>
      )}

      {viewing && viewingLedger && (
        <div className="modal-backdrop" onMouseDown={() => setViewing(null)}>
          <div className="master-modal detail-panel" role="dialog" aria-modal="true" onMouseDown={(e) => e.stopPropagation()}>
            <div className="modal-heading">
              <div>
                <p className="eyebrow">DISTRIBUTOR</p>
                <h3>{viewing.client_name}</h3>
              </div>
              <button className="icon-action" type="button" aria-label="Close" onClick={() => setViewing(null)}>
                ×
              </button>
            </div>

                    <dl className="detail-dl">
              <dt>Code</dt>
              <dd>{viewing.client_code}</dd>
              <dt>City</dt>
              <dd>{viewing.city || '—'}</dd>
              <dt>GSTIN</dt>
              <dd>{viewing.gstin || '—'}</dd>
              <dt>Credit terms</dt>
              <dd>{viewing.credit_limit != null ? `${money(viewing.credit_limit)} · ${viewing.credit_days ?? 0} days` : '—'}</dd>
              <dt>Orders handled for clients</dt>
              <dd>{viewingHandled?.count ?? 0}</dd>
              <dt>Metres distributed</dt>
              <dd>{(viewingHandled?.metres ?? 0).toLocaleString('en-IN', { maximumFractionDigits: 2 })} m ({viewingHandled?.rollCount ?? 0} roll(s) · {(viewingHandled?.rollMetres ?? 0).toLocaleString('en-IN', { maximumFractionDigits: 2 })} m issued)</dd>
              <dt>Total sales</dt>
              <dd>{money(viewingLedger.totalSales)}</dd>
              <dt>Total collected</dt>
              <dd>{money(viewingLedger.totalCollected)}</dd>
              <dt>Outstanding</dt>
              <dd className={viewingLedger.outstanding > 0 ? 'text-warn' : ''}>{money(viewingLedger.outstanding)}</dd>
            </dl>

            <h5 className="ledger-heading">Orders delivered to clients</h5>
            <div className="data-table-wrap">
              <table>
                <thead><tr><th>Order no.</th><th>Client</th><th>Status</th><th>Metres</th></tr></thead>
                <tbody>
                  {(viewingHandled?.list ?? []).slice(0, 8).map((o) => (
                    <tr key={o.id}>
                      <td>{o.order_number}</td>
                      <td>{o.clients?.client_name ?? '—'}</td>
                      <td><span className={`status-badge status-${o.status}`}>{o.status}</span></td>
                      <td>{(o.sale_order_items ?? []).filter((i) => isMetre(i.products?.unit)).reduce((s, i) => s + Number(i.quantity || 0), 0).toLocaleString('en-IN', { maximumFractionDigits: 2 })} m</td>
                    </tr>
                  ))}
                  {(viewingHandled?.list.length ?? 0) === 0 && <tr><td colSpan={4} className="empty-row">No client orders assigned to this distributor yet.</td></tr>}
                </tbody>
              </table>
            </div>

            <h5 className="ledger-heading">Recent orders</h5>
            <div className="data-table-wrap">
              <table>
                <thead><tr><th>Order no.</th><th>Status</th><th>Amount</th><th>Date</th></tr></thead>
                <tbody>
                  {viewingOrders.slice(0, 8).map((o) => (
                    <tr key={o.id}>
                      <td>{o.order_number}</td>
                      <td><span className={`status-badge status-${o.status}`}>{o.status}</span></td>
                      <td>{money(o.total_amount)}</td>
                      <td>{new Intl.DateTimeFormat(undefined, { dateStyle: 'medium' }).format(new Date(o.created_at))}</td>
                    </tr>
                  ))}
                  {viewingOrders.length === 0 && <tr><td colSpan={4} className="empty-row">No orders recorded yet.</td></tr>}
                </tbody>
              </table>
            </div>

            <h5 className="ledger-heading">Recent collections</h5>
            <div className="data-table-wrap">
              <table>
                <thead><tr><th>Amount</th><th>Mode</th><th>Date</th></tr></thead>
                <tbody>
                  {viewingCollections.slice(0, 8).map((c) => (
                    <tr key={c.id}>
                      <td>{money(c.amount)}</td>
                      <td className="capitalize">{c.mode}</td>
                      <td>{new Intl.DateTimeFormat(undefined, { dateStyle: 'medium' }).format(new Date(c.collected_at))}</td>
                    </tr>
                  ))}
                  {viewingCollections.length === 0 && <tr><td colSpan={3} className="empty-row">No collections recorded yet.</td></tr>}
                </tbody>
              </table>
            </div>

            <div className="modal-actions">
              <button type="button" className="primary-action" onClick={() => setViewing(null)}>
                Done
              </button>
            </div>
          </div>
        </div>
      )}
   
      {kpiView === 'credit' && (
        <KpiDetailModal
          eyebrow="CREDIT EXTENDED"
          title="Credit limit by distributor"
          subtitle={`${money(totalCreditExtended)} combined credit limit across ${creditRows.length} distributor(s)`}
          columns={['Distributor', 'Code', 'City', 'Credit limit', 'Credit days', 'Outstanding']}
          rows={creditRows.map((r) => ({ id: r.client.id, cells: [r.client.client_name, r.client.client_code, r.client.city || '—', money(r.client.credit_limit ?? 0), r.client.credit_days ?? '—', money(r.outstanding)] }))}
          emptyText="No distributor has a credit limit set."
          onClose={() => setKpiView(null)}
        />
      )}

      {kpiView === 'outstanding' && (
        <KpiDetailModal
          eyebrow="OUTSTANDING"
          title="Outstanding by distributor"
          subtitle={`${money(totalOutstanding)} outstanding across ${outstandingRows.length} distributor(s)`}
          columns={['Distributor', 'Code', 'Total sales', 'Collected', 'Outstanding', 'Credit limit']}
          rows={outstandingRows.map((r) => ({ id: r.client.id, cells: [r.client.client_name, r.client.client_code, money(r.totalSales), money(r.totalCollected), money(r.outstanding), r.client.credit_limit ? money(r.client.credit_limit) : '—'] }))}
          emptyText="No distributor has an outstanding balance."
          onClose={() => setKpiView(null)}
        />
      )}
    </section>
  );
}